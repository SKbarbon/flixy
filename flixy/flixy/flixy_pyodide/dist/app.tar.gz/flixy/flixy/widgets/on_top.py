





class onTop (object):
	
	def __init__ (self, mainview, content=None):
		self.__last_content = content
		self.content = content
	
	def update (self):
		pass
	
	def remove_self (self):
		pass
