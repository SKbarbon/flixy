import threading


def do_action(function, args=[]):
	if function == None: return
	try:
		import pyodide
		function(*args)
	except:
		threading.Thread(target=function, args=args, daemon=True).start()
