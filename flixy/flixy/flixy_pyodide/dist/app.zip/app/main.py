from flixy import *
import flixy

def main (page:flixy.Page):
    page.add(flixy.Text("Empty non-set flixy app.", expand_width=True))

flixy.app(target=main)