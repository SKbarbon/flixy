from .flixy import *
from .Demo.demo import start_demo
from .flixy.update import update_flixy
from .Learn.learn import learn_flixy
