from .flixy import *
from .Demo.demo import start_demo
from .Learn.learn import learn_flixy
