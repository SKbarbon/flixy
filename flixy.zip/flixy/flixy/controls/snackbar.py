import ui


class SnackBar (object):
	
	def __init__ (self):
		self.__self_ui = ui.View()
	
	def update(self):
		pass
