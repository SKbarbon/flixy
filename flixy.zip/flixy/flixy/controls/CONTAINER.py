




class Container (object):
	
	def __init__ (self):
		pass
	
	def update (self):
		pass
